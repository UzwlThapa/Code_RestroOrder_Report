import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'shopping-cart',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'm2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18',
        key: 'uebgi3',
      },
    ],
    [
      'path',
      {
        d: 'M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25',
        key: '1j7c9p',
      },
    ],
    ['circle', { cx: '18', cy: '20', r: '2', key: 't9985n' }],
    ['circle', { cx: '8', cy: '20', r: '2', key: 'ckkr5m' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ShoppingCart
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMi4wNSAyLjA1IDEuMDk5LS4wMjhhMSAxIDAgMCAxIDEuMDA4LjgxNWwyLjY5IDE0LjM0N0ExIDEgMCAwIDAgNy44MyAxOEgxOCIgLz4KICA8cGF0aCBkPSJNNC41NjMgNWgxNi40MzVhMSAxIDAgMCAxIC45ODEgMS4yMDRsLTEuMDI2IDYuMjI2QTIgMiAwIDAgMSAxOC45NjIgMTRINi4yNSIgLz4KICA8Y2lyY2xlIGN4PSIxOCIgY3k9IjIwIiByPSIyIiAvPgogIDxjaXJjbGUgY3g9IjgiIGN5PSIyMCIgcj0iMiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/shopping-cart
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ShoppingCart = createLucideIcon(__iconData);

export default ShoppingCart;
